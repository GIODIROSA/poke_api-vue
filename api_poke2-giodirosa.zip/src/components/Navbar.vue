<template>
  <div id="navbarpoke">
    <!-- navbar principal -->
    <nav class="navbar navbar-light bg-warning">
      <a class="navbar-brand" href="#">
        <img
          src="../assets/img/logo4.png"
          width="45"
          height="35"
          alt="logo2"
          loading="lazy"
        />
      </a>
    </nav>
  </div>
</template>

<script>
export default {
  name: "Navbar",
};
</script>

<style lang="scss" scoped></style>
